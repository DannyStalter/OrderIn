

<?=template_header('Home')?>

<div class="featured">
    <h2>Order IN</h2>
    <p>Welcome to the Order IN system!</p>
</div>

<?=template_footer()?>
