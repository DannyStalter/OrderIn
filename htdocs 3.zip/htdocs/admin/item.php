<?php
defined('admin') or exit;
// Default input item values - change rrp to time and add restaraunt
$item = array(
    'name' => '',
    'desc' => '',
    'price' => 0,
    'rrp' => 0,
    'quantity' => 1,
    'date_added' => date('Y-m-d\TH:i:s'),
    'img' => '',
    'imgs' => '',
    'categories' => array(),
    'options' => array(),
    'options_string' => ''
);
// Get all the categories from the database
$stmt = $pdo->query('SELECT * FROM categories');
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get all the images from the "imgs" directory
$imgs = glob('../imgs/*.{jpg,png,gif,jpeg,webp}', GLOB_BRACE);
// Add item images to the database*****
function addItemImages($pdo, $item_id) {
    if (isset($_POST['images_list'])) {
        $images_list = explode(',', $_POST['images_list']);
        $in  = str_repeat('?,', count($images_list) - 1) . '?';
        $stmt = $pdo->prepare('DELETE FROM items_images WHERE item_id = ? AND img NOT IN (' . $in . ')');
        $stmt->execute(array_merge([ $item_id ], $images_list));
        foreach ($images_list as $img) {
            if (empty($img)) continue;
            $stmt = $pdo->prepare('INSERT IGNORE INTO items_images (item_id,img) VALUES (?,?)');
            $stmt->execute([ $item_id, $img ]);
        }
    }
}
// Add item categories to the database*****
function addItemCategories($pdo, $item_id) {
    if (isset($_POST['categories_list'])) {
        $list = explode(',', $_POST['categories_list']);
        $in  = str_repeat('?,', count($list) - 1) . '?';
        $stmt = $pdo->prepare('DELETE FROM items_categories WHERE item_id = ? AND category_id NOT IN (' . $in . ')');
        $stmt->execute(array_merge([ $item_id ], $list));
        foreach ($list as $cat) {
            if (empty($cat)) continue;
            $stmt = $pdo->prepare('INSERT IGNORE INTO items_categories (item_id,category_id) VALUES (?,?)');
            $stmt->execute([ $item_id, $cat ]);
        }
    }
}
// Add item options to the database
function addItemOptions($pdo, $item_id) {
    if (isset($_POST['options'])) {
        $list = explode(',', $_POST['options']);
        $stmt = $pdo->prepare('SELECT * FROM items_options WHERE item_id = ?');
        $stmt->execute([ $_GET['id'] ]);
        $options = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $remove_list = array();
        foreach ($options as $option) {
            $option_string = $option['title'] . '__' . $option['name'] . '__' . $option['price'];
            if (!in_array($option_string, $list)) {
                $remove_list[] = $option['id'];
            } else {
                array_splice($list, array_search($option_string, $list), 1);
            }
        }
        $in = str_repeat('?,', count($remove_list) - 1) . '?';
        $stmt = $pdo->prepare('DELETE FROM items_options WHERE id IN (' . $in . ')');
        $stmt->execute($remove_list);
        foreach ($list as $option) {
            if (empty($option)) continue;
            $option = explode('__', $option);
            $stmt = $pdo->prepare('INSERT INTO items_options (title,name,price,item_id) VALUES (?,?,?,?)');
            $stmt->execute([ $option[0], $option[1], $option[2], $item_id ]);
        }
    }
}
if (isset($_GET['id'])) {
    // ID param exists, edit an existing item
    $page = 'Edit';
    if (isset($_POST['submit'])) {
        // Update the item
        $stmt = $pdo->prepare('UPDATE items SET name = ?, `desc` = ?, price = ?, rrp = ?, quantity = ?, img = ?, date_added = ? WHERE id = ?');
        $stmt->execute([ $_POST['name'], $_POST['desc'], $_POST['price'], $_POST['rrp'], $_POST['quantity'], $_POST['main_image'], date('Y-m-d H:i:s', strtotime($_POST['date'])), $_GET['id'] ]);
        addItemImages($pdo, $_GET['id']);
        addItemCategories($pdo, $_GET['id']);
        addItemOptions($pdo, $_GET['id']);
        header('Location: index.php?page=items');
        exit;
    }
    if (isset($_POST['delete'])) {
        // Delete the item and its images, categories, options
        $stmt = $pdo->prepare('DELETE p, pi, po, pc FROM items p LEFT JOIN items_images pi ON pi.item_id = p.id LEFT JOIN items_options po ON po.item_id = p.id LEFT JOIN items_categories pc ON pc.item_id = p.id WHERE p.id = ?');
        $stmt->execute([ $_GET['id'] ]);
        header('Location: index.php?page=items');
        exit;
    }
    // Get the item and its images from the database
    $stmt = $pdo->prepare('SELECT p.*, GROUP_CONCAT(pi.img) AS imgs FROM items p LEFT JOIN items_images pi ON p.id = pi.item_id WHERE p.id = ? GROUP BY p.id');
    $stmt->execute([ $_GET['id'] ]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    // Get the item categories
    $stmt = $pdo->prepare('SELECT c.name, c.id FROM items_categories pc JOIN categories c ON c.id = pc.category_id WHERE pc.item_id = ?');
    $stmt->execute([ $_GET['id'] ]);
    $item['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Get the item options
    $stmt = $pdo->prepare('SELECT * FROM items_options WHERE item_id = ?');
    $stmt->execute([ $_GET['id'] ]);
    $item['options'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $item['options_string'] = '';
    foreach($item['options'] as $option) {
        $item['options_string'] .= $option['title'] . '__' . $option['name'] . '__' . $option['price'] . ',';
    }
    $item['options_string'] = rtrim($item['options_string'], ',');
} else {
    // Create a new item
    $page = 'Create';
    if (isset($_POST['submit'])) {
        $stmt = $pdo->prepare('INSERT IGNORE INTO items (name,`desc`,price,rrp,quantity,img,date_added) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([ $_POST['name'], $_POST['desc'], $_POST['price'], $_POST['rrp'], $_POST['quantity'], $_POST['main_image'], date('Y-m-d H:i:s', strtotime($_POST['date'])) ]);
        addItemImages($pdo, $pdo->lastInsertId());
        addItemCategories($pdo, $_GET['id']);
        addItemOptions($pdo, $_GET['id']);
        header('Location: index.php?page=items');
        exit;
    }
}
?>

<?=template_admin_header($page . ' Item')?>

<h2><?=$page?> Item</h2>

<div class="content-block">

    <form action="" method="post" class="form responsive-width-100">

        <label for="name">Name</label>
        <input type="text" name="name" placeholder="Name" value="<?=$item['name']?>" required>

        <label for="desc">Description (HTML)</label>
        <textarea name="desc" placeholder="Item Description (HTML)"><?=$item['desc']?></textarea>

        <label for="price">Price</label>
        <input type="number" name="price" placeholder="Price" min="0" step=".01" value="<?=$item['price']?>" required>

        <label for="rrp">RRP</label>
        <input type="number" name="rrp" placeholder="RRP" min="0" step=".01" value="<?=$item['rrp']?>" required>

        <label for="quantity">Quantity</span></label>
        <input type="number" name="quantity" placeholder="Quantity" min="-1" value="<?=$item['quantity']?>" title="-1 = unlimited" required>

        <label for="date">Date Added</label>
        <input type="datetime-local" name="date" placeholder="Date" value="<?=date('Y-m-d\TH:i:s', strtotime($item['date_added']))?>" required>

        <label for="add_categories">Categories</label>
        <div style="display:flex;flex-flow:wrap;">
            <select name="add_categories" id="add_categories" style="width:50%;" multiple>
                <?php foreach ($categories as $cat): ?>
                <option value="<?=$cat['id']?>"><?=$cat['name']?></option>
                <?php endforeach; ?>
            </select>
            <select name="categories" style="width:50%;" multiple>
                <?php foreach ($item['categories'] as $cat): ?>
                <option value="<?=$cat['id']?>"><?=$cat['name']?></option>
                <?php endforeach; ?>
            </select>
            <button id="add_selected_categories" style="width:50%;">Add</button>
            <button id="remove_selected_categories" style="width:50%;">Remove</button>
            <input type="hidden" name="categories_list" value="<?=implode(',', array_column($item['categories'], 'id'))?>">
        </div>

        <label for="add_option">Options</label>
        <div style="display:flex;flex-flow:wrap;">
            <input type="text" name="option_title" placeholder="Option Title (e.g. Size)" style="width:47%;margin-right:13px;">
            <input type="text" name="option_name" placeholder="Option Name (e.g. Large)" style="width:50%;">
            <input type="number" name="option_price" min="0" step=".01" placeholder="Option Price (e.g. 15.00)">
            <button id="add_option" style="margin-bottom:10px;">Add</button>
            <select name="options" multiple>
                <?php foreach ($item['options'] as $option): ?>
                <option value="<?=$option['title']?>__<?=$option['name']?>__<?=$option['price']?>"><?=$option['title']?>,<?=$option['name']?>,<?=$option['price']?></option>
                <?php endforeach; ?>
            </select>
            <button id="remove_selected_options">Remove</button>
            <input type="hidden" name="options" value="<?=$item['options_string']?>">
        </div>

        <label for="add_images">Images</label>
        <div style="display:flex;flex-flow:wrap;">
            <select name="add_images" id="add_images" style="width:50%;" multiple>
                <?php foreach ($imgs as $img): ?>
                <option value="<?=basename($img)?>"><?=basename($img)?></option>
                <?php endforeach; ?>
            </select>
            <select name="images" style="width:50%;" multiple>
                <?php foreach (explode(',', $item['imgs']) as $img): ?>
                <?php if (!empty($img)): ?>
                <option value="<?=$img?>"><?=$img?></option>
                <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <button id="add_selected_images" style="width:50%;">Add</button>
            <button id="remove_selected_images" style="width:50%;">Remove</button>
            <input type="hidden" name="images_list" value="<?=$item['imgs']?>">
        </div>

        <div>
            <label for="main_image">Main Image</label>
            <select name="main_image" id="main_image">
                <?php foreach (explode(',', $item['imgs']) as $img): ?>
                <option value="<?=$img?>"<?=$item['img'] == $img ? ' selected' : ''?>><?=$img?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="submit-btns">
            <input type="submit" name="submit" value="Submit">
            <?php if ($page == 'Edit'): ?>
            <input type="submit" name="delete" value="Delete" class="delete">
            <?php endif; ?>
        </div>

    </form>

</div>

<script>
document.querySelector("#remove_selected_options").onclick = function(e) {
    e.preventDefault();
    document.querySelectorAll("select[name='options'] option").forEach(function(option) {
        if (option.selected) {
            let list = document.querySelector("input[name='options']").value.split(",");
            list.splice(list.indexOf(option.value), 1);
            document.querySelector("input[name='options']").value = list.join(",");
            option.remove();
        }
    });
};
document.querySelector("#add_option").onclick = function(e) {
    e.preventDefault();
    if (document.querySelector("input[name='option_title']").value == "") {
        document.querySelector("input[name='option_title']").focus();
        return;
    }
    if (document.querySelector("input[name='option_name']").value == "") {
        document.querySelector("input[name='option_name']").focus();
        return;
    }
    if (document.querySelector("input[name='option_price']").value == "") {
        document.querySelector("input[name='option_price']").focus();
        return;
    }
    let option = document.createElement("option");
    option.value = document.querySelector("input[name='option_title']").value + '__' + document.querySelector("input[name='option_name']").value + '__' + document.querySelector("input[name='option_price']").value;
    option.text = document.querySelector("input[name='option_title']").value + ',' + document.querySelector("input[name='option_name']").value + ',' + document.querySelector("input[name='option_price']").value;
    document.querySelector("select[name='options']").add(option);
    document.querySelector("input[name='option_title']").value = "";
    document.querySelector("input[name='option_name']").value = "";
    document.querySelector("input[name='option_price']").value = "";
    document.querySelectorAll("select[name='options'] option").forEach(function(option) {
        let list = document.querySelector("input[name='options']").value.split(",");
        if (!list.includes(option.value)) {
            list.push(option.value);
        }
        document.querySelector("input[name='options']").value = list.join(",");
    });
};
document.querySelector("#remove_selected_categories").onclick = function(e) {
    e.preventDefault();
    document.querySelectorAll("select[name='categories'] option").forEach(function(option) {
        if (option.selected) {
            let list = document.querySelector("input[name='categories_list']").value.split(",");
            list.splice(list.indexOf(option.value), 1);
            document.querySelector("input[name='categories_list']").value = list.join(",");
            option.remove();
        }
    });
};
document.querySelector("#add_selected_categories").onclick = function(e) {
    e.preventDefault();
    document.querySelectorAll("select[name='add_categories'] option").forEach(function(option) {
        if (option.selected) {
            let list = document.querySelector("input[name='categories_list']").value.split(",");
            if (!list.includes(option.value)) {
                list.push(option.value);
            }
            document.querySelector("input[name='categories_list']").value = list.join(",");
            document.querySelector("select[name='categories']").add(option.cloneNode(true));
        }
    });
};
document.querySelector("#remove_selected_images").onclick = function(e) {
    e.preventDefault();
    document.querySelectorAll("select[name='images'] option").forEach(function(option) {
        if (option.selected) {
            let images_list = document.querySelector("input[name='images_list']").value.split(",");
            images_list.splice(images_list.indexOf(option.value), 1);
            document.querySelector("input[name='images_list']").value = images_list.join(",");
            document.querySelectorAll("select[name='main_image'] option").forEach(i => i.value == option.value ? i.remove() : false);
            option.remove();
        }
    });
};
document.querySelector("#add_selected_images").onclick = function(e) {
    e.preventDefault();
    document.querySelectorAll("select[name='add_images'] option").forEach(function(option) {
        if (option.selected) {
            let images_list = document.querySelector("input[name='images_list']").value.split(",");
            if (!images_list.includes(option.value)) {
                images_list.push(option.value);
            }
            let add_to_main_images = true;
            document.querySelectorAll("select[name='main_image'] option").forEach(i => add_to_main_images = i.value == option.value ? false : add_to_main_images);
            document.querySelector("input[name='images_list']").value = images_list.join(",");
            document.querySelector("select[name='images']").add(option.cloneNode(true));
            if (add_to_main_images) {
                document.querySelector("select[name='main_image']").add(option.cloneNode(true));
            }
        }
    });
};
</script>

<?=template_admin_footer()?>
